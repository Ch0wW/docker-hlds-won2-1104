TFStats v2.0 readme file

v1.5 New Features
*Team Differentiation:  If a player plays on two different teams, tfstats 
	gathers stats for each team seperately, then when viewing that players 
	stats, there's a link to that player's merged stats. 
*Pseudonyms for players: This is so it's not confusing if players change their
	names. it uses the name they used for the most time, and also lists other
	names they used.
*DisplayMM2 switch: The user (the person who runs tfstats) can now choose if
	they want to display team messages or not.  a lot of clans e-mailed me asking
	me to take out mm2 messages from the dialogue readout.
*Stats Resume: Disconnected players resume their stats where they left off
	when they reconnect.  This doesn't work in lan games because there is no
	WONID to work with.
*Garbage handling: TFStats is more robust when it comes to garbage input now.

v1.5 Bug Fixes
*The team kill award now works
*medics don't get double kills anymore
*the dates are now correct
*RandomPC is now handled correctly

As always you can e-mail tfstats@valvesoftware.com with questions, comments
and feature suggestions.  Read the TFStats manual for full documentation

Thanks for using TFStats!
